import React, {Component} from 'react';
import {AreaChart, XAxis, YAxis, CartesianGrid, Tooltip, Area, } from 'recharts';

export default class Chart2 extends Component {

    constructor(props) {
        super(props);
        this.state = {
            data: [
                {
                    name: 'A',
                    vrijednost1: 2000,
                    vrijednost2: 3000,
                },
                {
                    name: 'B',
                    vrijednost1: 4451,
                    vrijednost2: 2151,
                },
                {
                    name: 'C',
                    vrijednost1: 1200,
                    vrijednost2: 3250,
                },
                {
                    name: 'D',
                    vrijednost1: 3521,
                    vrijednost2: 2151,
                },
                {
                    name: 'E',
                    vrijednost1: 1200,
                    vrijednost2: 2500,
                },
                {
                    name: 'F',
                    vrijednost1: 1000,
                    vrijednost2: 951,
                },
                {
                    name: 'G',
                    vrijednost1: 2200,
                    vrijednost2: 1200,
                },
            ]
        };
    }

        render()
        {
            const {data} = this.state;
            return (
                <div>
                    <AreaChart width={770} height={450} data={data}
                               margin={{ top: 50, right: 10, left: 100, bottom: 0 }}>
                        <defs>
                            <linearGradient id="colorUv" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#870606" stopOpacity={0.8}/>
                                <stop offset="95%" stopColor="#870606" stopOpacity={0}/>
                            </linearGradient>
                            <linearGradient id="colorPv" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor="#968a8a" stopOpacity={0.8}/>
                                <stop offset="95%" stopColor="#968a8a" stopOpacity={0}/>
                            </linearGradient>
                        </defs>
                        <XAxis dataKey="name" padding={{left:20, right:20}}/>
                        <YAxis />
                        <CartesianGrid strokeDasharray="1 1"/>
                        <Tooltip />
                        <Area type="monotone" dataKey="vrijednost1" stroke="#968a8a" fillOpacity={1} fill="url(#colorUv)" />
                        <Area type="monotone" dataKey="vrijednost2" stroke="#870606" fillOpacity={1} fill="url(#colorPv)" />
                    </AreaChart>
                </div>
            );
        }


}
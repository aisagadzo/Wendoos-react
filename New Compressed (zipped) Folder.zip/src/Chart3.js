import React, {Component} from 'react';
import {ComposedChart, XAxis, YAxis, CartesianGrid, Tooltip, Area, Line, Bar, Legend } from 'recharts';

export default class Chart3 extends Component {

    constructor(props) {
        super(props);
        this.state = {
            data: [
                {name: 'A', vrijednost1: 590, vrijednost2: 800, vrijednost3: 1400},
                {name: 'B', vrijednost1: 868, vrijednost2: 967, vrijednost3: 1506},
                {name: 'C', vrijednost1: 1397, vrijednost2: 1098, vrijednost3: 989},
                {name: 'D', vrijednost1: 1480, vrijednost2: 1200, vrijednost3: 1228},
                {name: 'E', vrijednost1: 1520, vrijednost2: 1108, vrijednost3: 1100},
                {name: 'F', vrijednost1: 1400, vrijednost2: 680, vrijednost3: 1700}]
        };
    }

    render()
    {
        const {data} = this.state;
        return (
            <div>
                <ComposedChart layout="vertical" width={600} height={400} data={data}
                               margin={{top: 20, right: 20, bottom: 20, left: 20}}>
                    <XAxis type="number"/>
                    <YAxis dataKey="name" type="category"/>
                    <Tooltip/>
                    <Legend layout='vertical' strokeWidth={20}/>
                    <CartesianGrid stroke='#f5f5f5'/>
                    <Area dataKey='vrijednost3' fill='#968a8a' stroke='#968a8a'/>
                    <Bar dataKey='vrijednost2' barSize={20} fill='#870606' stopOpacity={0.4}/>
                    <Line dataKey='vrijednost1' stroke='#ff7300'/>
                </ComposedChart>
            </div>
        );
    }


}
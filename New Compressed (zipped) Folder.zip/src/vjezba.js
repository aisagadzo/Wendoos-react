import React, {Component} from 'react';
import {BarChart, CartesianGrid, XAxis, YAxis, Tooltip, Legend, Bar} from 'recharts';

export default class IncorporationForm extends Component {
    constructor(props) {
        super(props);
        this.state = {
            data:[
            ],
            id:1,
        };
        this.handleNameChange = this.handleNameChange.bind(this);
        this.handleValueChange= this.handleValueChange.bind(this);
        this.handleAddValue = this.handleAddValue.bind(this);
    }

    handleNameChange(event){
        this.setState({ name: event.target.value });
    }

    handleValueChange(event) {
        console.log("test");
       const {name, value} = event.target;
       let trenutniIndex = this.state.data.findIndex( el => el.name === name);
       let noviData = this.state.data;
       noviData[trenutniIndex] = {
           name: name,
           value: value
       };

       this.setState({data: noviData});
       this.forceUpdate();
    };


    handleAddValue(){
        const novi = {
            name: 'area' + this.state.id,
            value: 7
        };
        this.setState({data:[...this.state.data, novi], id: this.state.id+1});
    }

    handleRemoveValue = (idx) => () => {
        this.setState({ nova_vrijednost: this.state.nova_vrijednost.filter((s, sidx) => idx !== sidx) });
    }

    render() {
        const data = this.state.data;



        return (
            <div>
                <BarChart width={730} height={250} data={data}
                          margin={{ top: 50, right: 10, left: 100, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3"/>
                    <XAxis dataKey="name"/>
                    <YAxis/>
                    <Tooltip/>
                    <Legend/>
                    <Bar dataKey="value" fill="#8884d8"/>
                </BarChart>
            <form onSubmit={this.handleSubmit}>

                {this.state.data.map(obj => (
                    <div>
                        <input
                            type="number"
                            name={obj.name}
                            value={obj.value}
                            onChange={this.handleValueChange}
                        />
                        {/*<button type="button" onClick={this.handleRemoveValue(idx)} className="small">-</button>*/}
                    </div>
                ))}
                <br/> <br/> <br/>
                <button type="button" onClick={this.handleAddValue} className="small">Dodaj vrijednost</button>
            </form>
            </div>
        )
    }

    componentDidCatch(error, info){
        console.log(error);
        console.log(info);
    }
}


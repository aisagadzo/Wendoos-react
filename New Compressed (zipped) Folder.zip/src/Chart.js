import React, {Component} from 'react';
import {BarChart, CartesianGrid, XAxis, YAxis, Tooltip, Legend, Bar} from 'recharts';

export default class Chart extends Component {

    constructor(props) {
        super(props);
        this.state = {
            data: [
                {
                    name: 'Prvi',
                    vrijednost1: 2000,
                    vrijednost2: 3000,
                },
                {
                    name: 'Drugi',
                    vrijednost1: 4451,
                    vrijednost2: 2151,
                },
            ],
        };
        this.promjena = this.promjena.bind(this);
    }

    promjena(){
        let {data} = this.state;
        let stara = data[0].vrijednost1;
        data[0].vrijednost1 = stara + 1000;
        this.setState({data: [...data]})
    }

        render()
        {
            const {data} = this.state;
            return (
                <div>
                    <BarChart width={730} height={250} data={data}
                              margin={{ top: 50, right: 10, left: 100, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3"/>
                        <XAxis dataKey="name"/>
                        <YAxis/>
                        <Tooltip/>
                        <Legend/>
                        <Bar dataKey="vrijednost1" fill="#8884d8"/>
                        <Bar dataKey="vrijednost2" fill="#82ca9d"/>
                    </BarChart>
                    <button onClick={this.promjena}>Klikni</button>
                </div>
            );
        }
}

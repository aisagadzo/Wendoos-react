import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Chart2 from './Chart2';
import Chart from './Chart';
import Chart3 from './Chart3';
import Chart4 from './Chart4';
import ChartUnos from './ChartUnos';
import IncorporationForm from './vjezba';




class App extends Component {
    render() {
        return (
            <div>
                <IncorporationForm/>
            </div>
        );
    }
}

export default App;
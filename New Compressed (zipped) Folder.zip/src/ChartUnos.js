import React, {Component} from 'react';
import {AreaChart, XAxis, YAxis, CartesianGrid, Tooltip, Area, } from 'recharts';

var divStyle = {
    background: "#eee",
    padding: "20px",
    margin_left:"100px",
    float: "left",
};


export default class ChartUnos extends Component {

    constructor(props) {
        super(props);
        this.state = {
            vrijednost1:0,
            vrijednost2:0,
            vrijednost3:0,
            vrijednost4:0,
            vrijednost1_:0,
            vrijednost2_:0,
            vrijednost3_:0,
            vrijednost4_:0,
        };
        this.handleChange = this.handleChange.bind(this);
    }

    handleChange(event) {
        const {name, value} = event.target;
        this.setState(
            {
                [name]:value
            }
        )
    }

    render()
    {
        const data = [
            {
                name:'A',
                vrijednost: this.state.vrijednost1,
                vrijednost_: this.state.vrijednost1_,
            },
            {
                name:'B',
                vrijednost: this.state.vrijednost2,
                vrijednost_: this.state.vrijednost2_,
            },
            {
                name:'C',
                vrijednost: this.state.vrijednost3,
                vrijednost_: this.state.vrijednost3_,
            },
            {
                name:'D',
                vrijednost: this.state.vrijednost4,
                vrijednost_: this.state.vrijednost4_,
            },
        ]

        return (
            <div>
                <AreaChart width={570} height={250} data={data}
                           margin={{ top: 50, right: 0, left: 10, bottom: 0 }}>
                    <defs>
                        <linearGradient id="colorUv" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#870606" stopOpacity={0.8}/>
                            <stop offset="95%" stopColor="#870606" stopOpacity={0}/>
                        </linearGradient>
                        <linearGradient id="colorPv" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#968a8a" stopOpacity={0.8}/>
                            <stop offset="95%" stopColor="#968a8a" stopOpacity={0}/>
                        </linearGradient>
                    </defs>
                    <XAxis dataKey="name" padding={{left:20, right:20}}/>
                    <YAxis />
                    <CartesianGrid strokeDasharray="1 1"/>
                    <Tooltip />
                    <Area type="monotone" dataKey="vrijednost" stroke="#968a8a" fillOpacity={1} fill="url(#colorUv)" />
                    <Area type="monotone" dataKey="vrijednost_" stroke="#870606" fillOpacity={1} fill="url(#colorPv)" />
                </AreaChart>
                <br/><br/>
                <div style={divStyle}>
                    A: <input type='number' name={'vrijednost1'} value={this.state.vrijednost1} onChange={this.handleChange}/>
                    <input type='number' name={'vrijednost1_'} value={this.state.vrijednost1_} onChange={this.handleChange}/><br/><br/>
                    B: <input type='number' name={'vrijednost2'} value={this.state.vrijednost2} onChange={this.handleChange}/>
                    <input type='number' name={'vrijednost2_'} value={this.state.vrijednost2_} onChange={this.handleChange}/><br/><br/>
                    C: <input type='number' name={'vrijednost3'} value={this.state.vrijednost3} onChange={this.handleChange}/>
                    <input type='number' name={'vrijednost3_'} value={this.state.vrijednost3_} onChange={this.handleChange}/><br/><br/>
                    D: <input type='number' name={'vrijednost4'} value={this.state.vrijednost4} onChange={this.handleChange}/>
                    <input type='number' name={'vrijednost4_'} value={this.state.vrijednost4_} onChange={this.handleChange}/><br/><br/>
                </div>

            </div>
        );
    }

    componentDidCatch(error, info){
        console.log(error);
        console.log(info);
    }


}